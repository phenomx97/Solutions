SPOOL solution1
SET SERVEROUTPUT ON
SET ECHO ON
SET FEEDBACK ON
SET LINESIZE 200
SET PAGESIZE 400

/* (1) First, the script inserts information about a new bank account. All information about a new account is up to you.
       The script must make an insertion permanent in a database.                                                        */

INSERT INTO ACCOUNT VALUES ( 9999964233, 'National Bank of Tokyo', 10000.00, 'savings' );

/* (2) Next, the script lists information about the new bank account created in the previous step.                       */

SELECT * FROM ACCOUNT WHERE account_num = '9999964233';

/* (3) Next, the script creates a database trigger, that updates a balance of a bank account each time a new transaction 
       is recorded in a database. A type of a database trigger is up to you.                                             */

CREATE TRIGGER transaction_insert
BEFORE DELETE OR INSERT OR UPDATE ON TRANSACTION
FOR EACH ROW

BEGIN 
 DBMS_OUTPUT.PUT_LINE('Transaction Inserted.');
 IF (:NEW.type = 'deposit') THEN 
 UPDATE ACCOUNT SET balance = balance + :NEW.amount
 WHERE account_num = :NEW.acc_num AND
 bank_name = :NEW.bank_name;
 END IF;

 IF (:NEW.type = 'withdrawal') THEN 
 UPDATE ACCOUNT SET balance = balance - :NEW.amount
 WHERE account_num = :NEW.acc_num AND
 bank_name = :NEW.bank_name;
 END IF;


END;
/
/* (4) Next, the script comprehensively tests the trigger. A test must include at least one new transaction of each type 
       (deposit, withdrawal)  operating on a bank account created in a step (1) and it must list a balance of the bank 
       account each time new transaction is recorded in a database. Insertion of each new transaction must be permanently 
       recorded in a database.                                                                                           */

INSERT INTO TRANSACTION VALUES ( 9999964233, 'National Bank of Tokyo', TO_DATE('2019-06-10 10:25:00','YYYY-MM-DD HH24:MI:SS'), 11300.00, 'deposit');

SELECT * FROM ACCOUNT WHERE account_num = '9999964233';

INSERT INTO TRANSACTION VALUES ( 9999964233, 'National Bank of Tokyo', TO_DATE('2019-06-11 10:25:00','YYYY-MM-DD HH24:MI:SS'), 1300.00, 'withdrawal');

SELECT * FROM ACCOUNT WHERE account_num = '9999964233';

/* (5) Finally, the script removes from a data dictionary a trigger created in a step (3).                               */
DROP TRIGGER transaction_insert;
DELETE FROM TRANSACTION WHERE acc_num ='9999964233';
DELETE FROM ACCOUNT WHERE account_num ='9999964233';

SPOOL OFF