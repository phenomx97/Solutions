import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.hbase.*;
import java.util.Map;
import java.util.NavigableMap

public class ISIT312Assignment3 {

	public void getRow(String title){
		Configuration conf = HBaseConfiguration.create();
		HTable table = new HTable(conf,"ISIT312Assignment3");
		Get get = new Get(Bytes.toBytes(title));
		get.setMaxVersions(3);
		get.addFamily(Bytes.toBytes("PROJECT"));
		get.addColumn(Bytes.toBytes("EMPLOYEE"),Bytes.toBytes("first-name"));
		get.addColumn(Bytes.toBytes("EMPLOYEE"),Bytes.toBytes("last-name"));
		
		Result result = table.get(get);
		String row = Bytes.toString(result.getRow());
		
		System.out.println("Row key: " + row);
		NavigableMap>> map = result.getMap();
		for (Map.Entry>> navigableMapEntry : map.entrySet()){
			String family = Bytes.toString(navigableMapEntry.getKey());
			System.out.println("\t" + family);
			NavigableMap> familyContents = navigableMapEntry.getValue();
			for (Map.Entry> mapEntry : familyContents.entrySet())){
				String qualifier = Bytes.toString(mapEntry.getKey());
				System.out.println("\t\t" + qualifier);
				NavigableMap qualifierContents = mapEntry.getValue();
				for (Map.Entry entry : qualifierContents.entrySet())){
					Long timestamp = entry.getKey();
					String value = Bytes.toString(entry.getValue());
					System.out.printf("\t\t\t%s, %d\n",value,timestamp);
				}
			}
	
		}
		table.close();
	}

	public static void main (String[] args) throws Exception {
		getRow("Big Data");
	}
}
